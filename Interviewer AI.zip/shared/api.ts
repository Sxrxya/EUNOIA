export interface Question {
  id: string;
  text: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface DemoResponse {
  message: string;
}

export interface AptitudeQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  category: 'quantitative' | 'logical' | 'verbal';
}

export interface AptitudeSession {
  id: string;
  score: number;
  totalQuestions: number;
  timeSpent: number;
  date: string;
}

export interface InterviewSession {
  id: string;
  company: string;
  role: string;
  difficulty: 'easy' | 'medium' | 'hard';
  startTime: string;
  status: 'pending' | 'in_progress' | 'completed';
}

export interface AIAnalysis {
  relevance: number;
  clarity: number;
  confidence: number;
  technicalDepth: number;
  feedback: string;
  emotionData?: {
    smile: number;
    eyeContact: number;
    stress: number;
  };
}

export interface Answer {
  id: string;
  sessionId: string;
  questionId: string;
  transcript: string;
  videoUrl?: string;
  analysis?: AIAnalysis;
  score: number;
}

export interface DashboardStats {
  averageScore: number;
  sessionsCount: number;
  skillTrends: {
    category: string;
    score: number;
  }[];
  weaknesses: string[];
}
