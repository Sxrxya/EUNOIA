import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Video,
  History,
  User,
  Menu,
  X,
  Sparkles,
  Zap,
  Brain
} from 'lucide-react';
import { Button } from './ui/button';

interface SidebarItemProps {
  icon: React.ElementType;
  label: string;
  href: string;
  active?: boolean;
}

const SidebarItem = ({ icon: Icon, label, href, active }: SidebarItemProps) => (
  <Link
    to={href}
    className={cn(
      "flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group",
      active 
        ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
    )}
  >
    <Icon className={cn("w-5 h-5", active ? "text-primary-foreground" : "group-hover:text-primary")} />
    <span className="font-medium">{label}</span>
  </Link>
);

export const Layout = ({ children }: { children: React.ReactNode }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const location = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: 'Overview', href: '/' },
    { icon: Video, label: 'Mock Interview', href: '/interview' },
    { icon: Brain, label: 'Aptitude Practice', href: '/aptitude' },
    { icon: History, label: 'Session History', href: '/history' },
    { icon: User, label: 'Profile', href: '/profile' },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-card/50 backdrop-blur-xl sticky top-0 h-screen">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-2 font-bold text-xl tracking-tight group">
            <motion.div
              className="bg-primary p-1.5 rounded-lg shadow-lg shadow-primary/20"
              whileHover={{ rotate: 180 }}
              transition={{ duration: 0.5 }}
            >
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </motion.div>
            <span className="group-hover:text-primary transition-colors">Interview<span className="text-primary group-hover:text-foreground">AI</span></span>
          </Link>
        </div>

        <nav className="flex-1 px-4 space-y-2 py-4">
          {navItems.map((item) => (
            <SidebarItem
              key={item.href}
              {...item}
              active={location.pathname === item.href}
            />
          ))}

          <div className="pt-6 px-3">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-4">Daily Goal</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Mock Sessions</span>
                <span className="font-bold text-primary">2/3</span>
              </div>
              <div className="h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: '66%' }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>
            </div>
          </div>
        </nav>

        <div className="p-4 mt-auto">
          <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl p-4 border border-primary/20 relative overflow-hidden group">
            <Zap className="w-8 h-8 text-primary/20 absolute -right-2 -bottom-2 group-hover:scale-110 transition-transform" />
            <p className="text-sm font-semibold mb-1">Upgrade to Pro</p>
            <p className="text-xs text-muted-foreground mb-3">Get unlimited AI feedback and specialized roles.</p>
            <Button size="sm" className="w-full text-xs h-8">Upgrade Now</Button>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="flex-1 flex flex-col">
        <header className="md:hidden flex items-center justify-between p-4 border-b bg-card">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <Sparkles className="w-5 h-5 text-primary" />
            <span>InterviewAI</span>
          </Link>
          <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </header>

        {/* Mobile Nav Menu */}
        {isMobileMenuOpen && (
          <nav className="md:hidden bg-card border-b p-4 space-y-2 animate-in slide-in-from-top duration-200">
            {navItems.map((item) => (
              <SidebarItem
                key={item.href}
                {...item}
                active={location.pathname === item.href}
              />
            ))}
          </nav>
        )}

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          <div className="absolute inset-0 bg-grid-white/[0.02] -z-10" />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent -z-10" />
          <div className="flex-1 p-4 md:p-8 lg:p-10 max-w-7xl mx-auto w-full overflow-y-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
