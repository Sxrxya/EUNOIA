import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { 
  Trophy, 
  Clock, 
  TrendingUp, 
  AlertTriangle, 
  ChevronRight,
  Target,
  FileText,
  Star
} from 'lucide-react';
import { motion } from 'framer-motion';

const data = [
  { name: 'Session 1', score: 65, clarity: 60, depth: 55 },
  { name: 'Session 2', score: 72, clarity: 70, depth: 62 },
  { name: 'Session 3', score: 68, clarity: 75, depth: 58 },
  { name: 'Session 4', score: 85, clarity: 82, depth: 78 },
  { name: 'Session 5', score: 92, clarity: 88, depth: 90 },
];

const skillData = [
  { subject: 'Data Structures', score: 90 },
  { subject: 'Algorithms', score: 85 },
  { subject: 'System Design', score: 70 },
  { subject: 'Behavioral', score: 95 },
  { subject: 'OS/Networking', score: 60 },
];

const History = () => {
  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Performance Dashboard</h1>
          <p className="text-muted-foreground">Track your progress and analyze your interview strengths.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" size="sm" className="gap-2">
            <FileText className="w-4 h-4" />
            Export Report
          </Button>
          <Button size="sm" className="gap-2">
            <TrendingUp className="w-4 h-4" />
            View Insights
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Overall Rating', value: '84/100', icon: Trophy, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
          { label: 'Avg Confidence', value: '78%', icon: Target, color: 'text-primary', bg: 'bg-primary/10' },
          { label: 'Total Sessions', value: '12', icon: Clock, color: 'text-blue-500', bg: 'bg-blue-500/10' },
          { label: 'Next Goal', value: 'L5 Prep', icon: Star, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((stat, i) => (
          <Card key={i} className="border-primary/5 bg-card/50">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-2xl ${stat.bg} ${stat.color}`}>
                  <stat.icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-12 gap-6">
        {/* Main Chart */}
        <Card className="lg:col-span-8 border-primary/5 bg-card/50">
          <CardHeader>
            <CardTitle className="text-lg">Score Trend Analysis</CardTitle>
            <CardDescription>Performance across your last 5 AI-evaluated sessions.</CardDescription>
          </CardHeader>
          <CardContent className="h-[350px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}%`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '12px' }}
                  itemStyle={{ color: 'hsl(var(--primary))' }}
                />
                <Area type="monotone" dataKey="score" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorScore)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Skill Breakdown */}
        <Card className="lg:col-span-4 border-primary/5 bg-card/50">
          <CardHeader>
            <CardTitle className="text-lg">Skill Metrics</CardTitle>
            <CardDescription>Relative performance by category.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 mt-4">
            {skillData.map((skill, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{skill.subject}</span>
                  <span className="text-muted-foreground">{skill.score}%</span>
                </div>
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${skill.score}%` }}
                    transition={{ duration: 1, delay: i * 0.1 }}
                    className="h-full bg-primary rounded-full" 
                  />
                </div>
              </div>
            ))}
            <div className="pt-4 border-t border-primary/5">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-orange-500/10 border border-orange-500/20">
                <AlertTriangle className="w-5 h-5 text-orange-500 mt-0.5" />
                <div>
                  <p className="text-xs font-bold text-orange-500 uppercase">Improvement Area</p>
                  <p className="text-sm text-muted-foreground">Your OS & Networking scores are lower than your Algorithms. Try the "Advanced OS" practice track.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Sessions List */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Recent Sessions</h2>
        <div className="grid gap-4">
          {[
            { id: '1', role: 'SDE II', company: 'Google', date: '2 hours ago', score: 92, difficulty: 'Hard' },
            { id: '2', role: 'Frontend Intern', company: 'Meta', date: 'Yesterday', score: 85, difficulty: 'Medium' },
            { id: '3', role: 'Data Scientist', company: 'Amazon', date: '3 days ago', score: 68, difficulty: 'Hard' },
          ].map((session) => (
            <Card key={session.id} className="group hover:border-primary/20 transition-all cursor-pointer border-primary/5 bg-card/50">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/5 flex items-center justify-center font-bold text-primary">
                    {session.score}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold">{session.role}</h4>
                      <Badge variant="secondary" className="text-[10px] py-0">{session.difficulty}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{session.company} • {session.date}</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="group-hover:translate-x-1 transition-transform">
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default History;
