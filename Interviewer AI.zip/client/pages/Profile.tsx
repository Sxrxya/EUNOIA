import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  User, 
  Mail, 
  Linkedin, 
  Github, 
  Settings, 
  Bell, 
  Shield, 
  LogOut,
  Camera,
  Sparkles
} from 'lucide-react';

const Profile = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10">
      <div className="flex items-center gap-6">
        <div className="relative group">
          <div className="w-24 h-24 rounded-3xl bg-primary/10 flex items-center justify-center border-4 border-background shadow-xl">
            <User className="w-12 h-12 text-primary" />
          </div>
          <Button size="icon" variant="secondary" className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity">
            <Camera className="w-4 h-4" />
          </Button>
        </div>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">John Doe</h1>
          <p className="text-muted-foreground flex items-center gap-2">
            Aspiring Software Engineer
            <Badge variant="secondary" className="bg-primary/5 text-primary border-none text-[10px]">PREMIUM</Badge>
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Sidebar Settings */}
        <div className="space-y-2">
          {[
            { label: 'General Info', icon: User, active: true },
            { label: 'Notifications', icon: Bell },
            { label: 'Security', icon: Shield },
            { label: 'Social Connections', icon: Linkedin },
            { label: 'Billing', icon: Settings },
          ].map((item, i) => (
            <Button
              key={i}
              variant={item.active ? 'secondary' : 'ghost'}
              className="w-full justify-start gap-3 h-11 px-4"
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Button>
          ))}
          <Button variant="ghost" className="w-full justify-start gap-3 h-11 px-4 text-destructive hover:text-destructive hover:bg-destructive/10">
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2 space-y-6">
          <Card className="border-primary/5 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>Update your profile details and career goals.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Full Name</label>
                  <Input defaultValue="John Doe" className="bg-background/50 border-primary/5" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</label>
                  <Input defaultValue="john.doe@university.edu" className="bg-background/50 border-primary/5" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Career Bio</label>
                <textarea 
                  className="w-full h-24 rounded-lg border border-primary/5 bg-background/50 p-3 text-sm outline-none focus:ring-2 ring-primary/20"
                  defaultValue="CS Senior at Stanford. Passionate about AI, Distributed Systems, and building scalable products."
                />
              </div>
              <div className="flex justify-end pt-2">
                <Button className="gap-2">
                  <Sparkles className="w-4 h-4" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/5 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Connected Accounts</CardTitle>
              <CardDescription>Link your profiles for personalized AI coaching.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-xl border bg-background/50">
                <div className="flex items-center gap-3">
                  <Linkedin className="w-5 h-5 text-[#0077b5]" />
                  <div>
                    <p className="font-semibold text-sm">LinkedIn</p>
                    <p className="text-xs text-muted-foreground text-green-500 font-medium">Synced • 2 days ago</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">Reconnect</Button>
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl border bg-background/50">
                <div className="flex items-center gap-3">
                  <Github className="w-5 h-5" />
                  <div>
                    <p className="font-semibold text-sm">GitHub</p>
                    <p className="text-xs text-muted-foreground">Not connected</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">Connect</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;
