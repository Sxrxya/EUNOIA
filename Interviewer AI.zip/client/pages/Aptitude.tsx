import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Brain, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  XCircle, 
  Timer,
  Award,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { AptitudeQuestion } from '@shared/api';
import { toast } from 'sonner';

const Aptitude = () => {
  const [questions, setQuestions] = useState<AptitudeQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);

  useEffect(() => {
    fetch('/api/aptitude')
      .then(res => res.json())
      .then(data => setQuestions(data));
  }, []);

  useEffect(() => {
    if (timeLeft > 0 && !isFinished && !showExplanation) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (timeLeft === 0 && !showExplanation) {
      handleNext();
    }
  }, [timeLeft, isFinished, showExplanation]);

  const handleOptionSelect = (option: string) => {
    if (showExplanation) return;
    setSelectedOption(option);
    setShowExplanation(true);
    if (option === questions[currentIndex].correctAnswer) {
      setScore(prev => prev + 1);
      toast.success("Correct Answer!");
    } else {
      toast.error("Incorrect Answer.");
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setShowExplanation(false);
      setTimeLeft(60);
    } else {
      setIsFinished(true);
    }
  };

  if (questions.length === 0) return <div className="flex items-center justify-center h-full">Loading...</div>;

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-4xl mx-auto h-full space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <Brain className="w-8 h-8 text-primary" />
            Aptitude Practice
          </h1>
          <p className="text-muted-foreground text-sm">Enhance your quantitative, logical, and verbal skills.</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="outline" className="h-8 px-4 gap-2 border-primary/20">
            <Timer className="w-3.5 h-3.5" />
            00:{timeLeft < 10 ? `0${timeLeft}` : timeLeft}
          </Badge>
          <Badge className="bg-primary/10 text-primary border-none h-8 px-4">
            SCORE: {score}/{questions.length}
          </Badge>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!isFinished ? (
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <Card className="border-primary/10 shadow-xl overflow-hidden bg-card/50 backdrop-blur-sm">
              <div className="h-1 bg-muted">
                <motion.div 
                  className="h-full bg-primary" 
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
                />
              </div>
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="secondary" className="uppercase tracking-widest text-[10px] font-bold">
                    {currentQ.category}
                  </Badge>
                  <span className="text-xs text-muted-foreground">Question {currentIndex + 1} of {questions.length}</span>
                </div>
                <CardTitle className="text-xl md:text-2xl leading-relaxed">
                  {currentQ.question}
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {currentQ.options.map((option, idx) => (
                  <Button
                    key={idx}
                    variant={selectedOption === option ? (option === currentQ.correctAnswer ? 'default' : 'destructive') : 'outline'}
                    className={cn(
                      "h-16 text-left justify-start px-6 text-lg relative overflow-hidden group",
                      showExplanation && option === currentQ.correctAnswer && "border-green-500 bg-green-500/10 text-green-700",
                      showExplanation && selectedOption === option && option !== currentQ.correctAnswer && "border-red-500 bg-red-500/10 text-red-700"
                    )}
                    onClick={() => handleOptionSelect(option)}
                    disabled={showExplanation}
                  >
                    <span className="w-8 h-8 rounded-full border border-current flex items-center justify-center mr-4 text-sm font-bold group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    {option}
                    {showExplanation && option === currentQ.correctAnswer && (
                      <CheckCircle2 className="w-5 h-5 ml-auto text-green-500" />
                    )}
                    {showExplanation && selectedOption === option && option !== currentQ.correctAnswer && (
                      <XCircle className="w-5 h-5 ml-auto text-red-500" />
                    )}
                  </Button>
                ))}
              </CardContent>
              {showExplanation && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="px-6 pb-6"
                >
                  <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
                    <p className="text-xs font-bold uppercase text-primary mb-2 flex items-center gap-2">
                      <BookOpen className="w-3.5 h-3.5" />
                      Explanation
                    </p>
                    <p className="text-sm text-muted-foreground italic leading-relaxed">
                      {currentQ.explanation}
                    </p>
                    <div className="mt-4 flex justify-end">
                      <Button onClick={handleNext}>
                        Next Question
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </Card>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center text-center py-12 space-y-8"
          >
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center">
                <Award className="w-16 h-16 text-primary" />
              </div>
              <motion.div 
                className="absolute inset-0"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
              >
                <div className="h-full w-full border-4 border-dashed border-primary/20 rounded-full" />
              </motion.div>
            </div>
            <div className="space-y-2">
              <h2 className="text-4xl font-bold">Practice Completed!</h2>
              <p className="text-xl text-muted-foreground">
                You scored <span className="text-primary font-bold">{score}</span> out of <span className="font-bold">{questions.length}</span> questions correctly.
              </p>
            </div>
            <div className="flex gap-4">
              <Button size="lg" onClick={() => window.location.reload()}>Try Again</Button>
              <Button size="lg" variant="outline" asChild>
                <a href="/">Back to Dashboard</a>
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Aptitude;
