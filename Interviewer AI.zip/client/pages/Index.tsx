import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  ArrowRight,
  Target,
  Zap,
  BarChart3,
  ShieldCheck,
  Building2,
  Cpu,
  Microscope,
  Briefcase,
  Brain,
  CheckCircle2,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const FeatureCard = ({ icon: Icon, title, description, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
  >
    <Card className="h-full border-primary/5 bg-card/50 backdrop-blur-sm hover:border-primary/20 transition-colors">
      <CardHeader>
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <CardTitle className="text-xl">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const Index = () => {
  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <section className="relative pt-10 pb-8 md:pt-16 md:pb-12 max-w-6xl mx-auto overflow-hidden rounded-3xl">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/6122305/pexels-photo-6122305.jpeg"
            alt="Hero Background"
            className="w-full h-full object-cover opacity-10 grayscale-[0.5]"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background" />
        </div>

        <div className="relative z-10 text-center px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="secondary" className="mb-6 py-1.5 px-4 rounded-full bg-primary/5 text-primary border-primary/10 animate-pulse">
              <Sparkles className="w-3.5 h-3.5 mr-2" />
              The Future of AI Career Coaching
            </Badge>
            <h1 className="text-4xl md:text-7xl font-extrabold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-foreground via-foreground to-muted-foreground leading-[1.1]">
              Master Your Next Interview with <span className="text-primary italic">Precision AI</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              Simulate real-world technical interviews at top-tier companies. Get instant, deep-dive feedback on your technical depth, body language, and confidence.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/interview">
                <Button size="lg" className="h-14 px-10 text-lg shadow-2xl shadow-primary/30 hover:scale-105 transition-all group rounded-2xl">
                  Start Mock Interview
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/aptitude">
                <Button size="lg" variant="outline" className="h-14 px-10 text-lg bg-background/50 border-primary/20 hover:bg-primary/5 backdrop-blur-sm rounded-2xl">
                  Practice Aptitude
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats/Social Proof */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto">
        {[
          { label: 'AI Simulations', value: '10k+' },
          { label: 'Users Placed', value: '2.5k' },
          { label: 'Interview Roles', value: '50+' },
          { label: 'Avg Score Improvement', value: '42%' }
        ].map((stat, i) => (
          <div key={i} className="text-center p-6 rounded-2xl bg-secondary/50 backdrop-blur-sm border border-primary/5">
            <p className="text-2xl font-bold text-foreground mb-1">{stat.value}</p>
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Core Features */}
      <section className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Why Industry Leaders Use InterviewAI</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our multi-modal AI engine analyzes every nuance of your performance to ensure you're ready for the most hiring bars.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <FeatureCard
            icon={Zap}
            title="Real-time Multi-modal Analysis"
            description="We process voice tone, facial micro-expressions, and technical accuracy simultaneously using high-performance edge AI."
            delay={0.1}
          />
          <FeatureCard
            icon={Brain}
            title="Aptitude Mastery"
            description="Master quantitative, logical, and verbal reasoning with our adaptive question engine designed for elite candidates."
            delay={0.2}
          />
          <FeatureCard
            icon={ShieldCheck}
            title="Company-Specific Simulators"
            description="Our database of 1000+ real interview questions from Google, Amazon, and Meta ensures you're never caught off guard."
            delay={0.3}
          />
        </div>
      </section>

      {/* Aptitude Showcase */}
      <section className="grid md:grid-cols-2 gap-8 items-center bg-primary/[0.02] rounded-[2rem] p-8 md:p-12 border border-primary/5">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold">
            <Zap className="w-3.5 h-3.5" />
            NEW FEATURE
          </div>
          <h2 className="text-4xl font-bold tracking-tight leading-tight">Crack the Aptitude Code with AI-Driven Practice</h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Interviews aren't just about technical depth. Our new Aptitude section helps you master the mental agility required for top-tier hiring assessments.
          </p>
          <ul className="space-y-3">
            {[
              "Adaptive Difficulty Scaling",
              "Detailed Step-by-Step Explanations",
              "Performance Benchmarking against Peers",
              "Daily Challenge Rewards"
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-3 text-sm font-medium">
                <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                  <CheckCircle2 className="w-3 h-3 text-primary" />
                </div>
                {item}
              </li>
            ))}
          </ul>
          <Link to="/aptitude">
            <Button size="lg" className="rounded-xl group">
              Try Aptitude Practice
              <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
        <div className="relative aspect-square rounded-3xl overflow-hidden shadow-2xl group">
          <img
            src="https://images.pexels.com/photos/16544949/pexels-photo-16544949.jpeg"
            alt="Practice Session"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-8">
            <div className="flex items-center gap-4 bg-white/10 backdrop-blur-xl p-4 rounded-2xl border border-white/10 w-full">
              <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-bold">Daily Challenge</p>
                <p className="text-white/70 text-xs uppercase tracking-widest font-semibold">Live Now • 1,240 practicing</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Role Selection Grid */}
      <section className="bg-secondary/30 rounded-3xl p-8 md:p-12 border border-primary/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 blur-3xl rounded-full -mr-32 -mt-32" />
        <div className="relative">
          <h2 className="text-2xl font-bold mb-8 flex items-center gap-3">
            <Cpu className="w-6 h-6 text-primary" />
            Choose Your Career Simulation
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {[
              { role: 'AI Intern', icon: Microscope, company: 'DeepMind', difficulty: 'Hard', color: 'bg-blue-500/10 text-blue-500' },
              { role: 'SDE II', icon: Cpu, company: 'Google', difficulty: 'Medium', color: 'bg-green-500/10 text-green-500' },
              { role: 'Aptitude Pro', icon: Brain, company: 'LeetCode', difficulty: 'Hard', color: 'bg-orange-500/10 text-orange-500', href: '/aptitude' },
              { role: 'Data Scientist', icon: BarChart3, company: 'Amazon', difficulty: 'Medium', color: 'bg-purple-500/10 text-purple-500' },
              { role: 'Product Manager', icon: Briefcase, company: 'Meta', difficulty: 'Medium', color: 'bg-pink-500/10 text-pink-500' }
            ].map((item, i) => (
              <Link key={i} to={item.href || '/interview'}>
                <Card className="group hover:ring-2 ring-primary/50 transition-all cursor-pointer bg-card/80 border-primary/5 h-full overflow-hidden relative">
                  <div className={cn("absolute top-0 right-0 w-16 h-16 -mr-8 -mt-8 rounded-full blur-2xl opacity-20", item.color.split(' ')[0])} />
                  <CardContent className="p-6 relative z-10">
                    <div className="flex items-center gap-3 mb-4">
                      <div className={cn("p-2 rounded-lg", item.color)}>
                        <item.icon className="w-5 h-5" />
                      </div>
                      <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-tighter">{item.difficulty}</Badge>
                    </div>
                    <h3 className="font-bold mb-1 group-hover:text-primary transition-colors">{item.role}</h3>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Building2 className="w-3 h-3" />
                      {item.company} Standard
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
