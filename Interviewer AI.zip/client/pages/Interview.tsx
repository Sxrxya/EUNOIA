import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Camera, 
  Mic, 
  Video as VideoIcon, 
  VideoOff, 
  MicOff, 
  Play, 
  Square, 
  ChevronRight, 
  ChevronLeft,
  Sparkles,
  AlertCircle,
  Settings2,
  Trophy,
  BrainCircuit,
  Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const Interview = () => {
  const [step, setStep] = useState<'config' | 'setup' | 'interview' | 'submitting'>('config');
  const [config, setConfig] = useState({
    role: 'SDE Intern',
    company: 'Google',
    difficulty: 'Medium'
  });
  
  const [cameraActive, setCameraActive] = useState(true);
  const [micActive, setMicActive] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes per question
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const mockQuestions = [
    { id: '1', text: 'Can you explain the difference between a process and a thread?', category: 'OS' },
    { id: '2', text: 'How do you ensure data consistency in a distributed system?', category: 'System Design' },
    { id: '3', text: 'Tell me about a time you had to deal with a difficult technical challenge.', category: 'Behavioral' },
  ];

  useEffect(() => {
    if (step === 'setup' || step === 'interview') {
      startCamera();
    }
    return () => stopCamera();
  }, [step]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0) {
      handleNextQuestion();
    }
    return () => clearInterval(timer);
  }, [isRecording, timeLeft]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      streamRef.current = stream;
    } catch (err) {
      toast.error("Could not access camera/microphone. Please check permissions.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
  };

  const handleStartInterview = () => {
    setStep('interview');
    setIsRecording(true);
    setTimeLeft(120);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < mockQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setTimeLeft(120);
    } else {
      handleFinish();
    }
  };

  const handleFinish = () => {
    setIsRecording(false);
    setStep('submitting');
    setTimeout(() => {
      toast.success("Interview completed! Analyzing your responses...");
      // In a real app, we would redirect to the report page
    }, 2000);
  };

  return (
    <div className="max-w-6xl mx-auto h-full flex flex-col">
      <AnimatePresence mode="wait">
        {step === 'config' && (
          <motion.div
            key="config"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex-1 flex items-center justify-center"
          >
            <Card className="w-full max-w-2xl border-primary/10 shadow-2xl bg-card/50 backdrop-blur-xl">
              <CardHeader className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Settings2 className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-3xl">Configure Simulation</CardTitle>
                <CardDescription>Select your target role and company to calibrate the AI coach.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">Target Company</label>
                    <select 
                      className="w-full h-11 rounded-lg border bg-background px-3 outline-none focus:ring-2 ring-primary/20"
                      value={config.company}
                      onChange={(e) => setConfig({...config, company: e.target.value})}
                    >
                      <option>Google</option>
                      <option>Amazon</option>
                      <option>Meta</option>
                      <option>OpenAI</option>
                      <option>Netflix</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">Job Role</label>
                    <select 
                      className="w-full h-11 rounded-lg border bg-background px-3 outline-none focus:ring-2 ring-primary/20"
                      value={config.role}
                      onChange={(e) => setConfig({...config, role: e.target.value})}
                    >
                      <option>SDE Intern</option>
                      <option>Software Engineer (L3/L4)</option>
                      <option>AI Engineer</option>
                      <option>Data Scientist</option>
                      <option>Product Manager</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold">Difficulty Level</label>
                  <div className="grid grid-cols-3 gap-3">
                    {['Easy', 'Medium', 'Hard'].map((d) => (
                      <Button
                        key={d}
                        variant={config.difficulty === d ? 'default' : 'outline'}
                        className="h-10"
                        onClick={() => setConfig({...config, difficulty: d})}
                      >
                        {d}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full h-12 text-lg" onClick={() => setStep('setup')}>
                  Continue to System Check
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        )}

        {step === 'setup' && (
          <motion.div
            key="setup"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex-1 grid md:grid-cols-2 gap-8 items-center"
          >
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                AI CALIBRATION READY
              </div>
              <h2 className="text-4xl font-bold tracking-tight">System Check</h2>
              <p className="text-muted-foreground">
                Ensure your camera and microphone are working correctly. The AI will monitor your eye contact, expressions, and voice clarity.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl border bg-card/50">
                  <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded-lg", cameraActive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                      <Camera className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">Camera Feed</p>
                      <p className="text-xs text-muted-foreground">{cameraActive ? 'Connected' : 'Not detected'}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setCameraActive(!cameraActive)}>
                    {cameraActive ? <VideoOff className="w-4 h-4" /> : <VideoIcon className="w-4 h-4" />}
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl border bg-card/50">
                  <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded-lg", micActive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                      <Mic className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">Microphone</p>
                      <p className="text-xs text-muted-foreground">{micActive ? 'Active' : 'Muted'}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setMicActive(!micActive)}>
                    {micActive ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button variant="outline" className="h-12 px-6" onClick={() => setStep('config')}>Back</Button>
                <Button className="h-12 flex-1 text-lg" onClick={handleStartInterview}>Start Simulation</Button>
              </div>
            </div>

            <div className="aspect-video rounded-3xl bg-black relative overflow-hidden ring-4 ring-primary/10 group shadow-2xl">
              <video 
                ref={videoRef} 
                autoPlay 
                muted 
                playsInline 
                className={cn("w-full h-full object-cover grayscale transition-all", cameraActive ? "opacity-100" : "opacity-0")}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full border-2 border-white/20 flex items-center justify-center bg-white/10 backdrop-blur-md">
                    <BrainCircuit className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-white text-sm font-medium">AI Coach Monitoring Active</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'interview' && (
          <motion.div
            key="interview"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 grid lg:grid-cols-12 gap-6 h-full"
          >
            {/* Left: Question Panel */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              <Card className="flex-1 border-primary/10 bg-card/50 backdrop-blur-xl flex flex-col overflow-hidden">
                <CardHeader className="border-b bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="text-xs px-2 py-0 h-5">
                      QUESTION {currentQuestionIndex + 1} OF {mockQuestions.length}
                    </Badge>
                    <div className="flex items-center gap-2 text-primary font-mono text-sm font-bold">
                      <Play className="w-3.5 h-3.5 animate-pulse" fill="currentColor" />
                      00:{timeLeft < 10 ? `0${timeLeft}` : timeLeft}
                    </div>
                  </div>
                  <Progress value={(timeLeft / 120) * 100} className="h-1" />
                </CardHeader>
                <CardContent className="flex-1 p-8 flex flex-col justify-center">
                  <div className="space-y-4">
                    <Badge className="bg-primary/10 text-primary border-none">{mockQuestions[currentQuestionIndex].category}</Badge>
                    <h3 className="text-2xl md:text-3xl font-bold leading-tight">
                      {mockQuestions[currentQuestionIndex].text}
                    </h3>
                  </div>
                </CardContent>
                <CardFooter className="border-t bg-muted/30 p-4 flex justify-between">
                  <Button variant="ghost" size="sm" disabled={currentQuestionIndex === 0} onClick={() => setCurrentQuestionIndex(i => i-1)}>
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  <Button size="sm" onClick={handleNextQuestion}>
                    {currentQuestionIndex === mockQuestions.length - 1 ? 'Finish' : 'Next Question'}
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardFooter>
              </Card>

              {/* Real-time Analysis Widget */}
              <Card className="border-primary/5 bg-secondary/20 p-4">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                    <Activity className="w-3.5 h-3.5 text-primary" />
                    Emotion & Confidence AI
                  </p>
                  <span className="text-[10px] text-muted-foreground">LIVE ANALYSIS</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Eye Contact', value: 85, color: 'bg-green-500' },
                    { label: 'Confidence', value: 72, color: 'bg-primary' },
                    { label: 'Smile/Vibe', value: 45, color: 'bg-orange-500' }
                  ].map((stat, i) => (
                    <div key={i} className="space-y-1.5">
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-muted-foreground">{stat.label}</span>
                        <span className="font-bold">{stat.value}%</span>
                      </div>
                      <div className="h-1 w-full bg-muted rounded-full overflow-hidden">
                        <div className={cn("h-full rounded-full transition-all duration-1000", stat.color)} style={{ width: `${stat.value}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            {/* Right: Camera View */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              <div className="flex-1 aspect-video rounded-3xl bg-black relative overflow-hidden shadow-2xl ring-1 ring-white/10">
                <video 
                  ref={videoRef} 
                  autoPlay 
                  muted 
                  playsInline 
                  className="w-full h-full object-cover grayscale-[0.2]"
                />
                
                {/* Recording Overlay */}
                <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-500/20 text-red-500 backdrop-blur-md border border-red-500/30">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Recording Response</span>
                </div>

                {/* AI HUD Elements */}
                <div className="absolute top-6 right-6">
                  <div className="w-12 h-12 rounded-full border-2 border-primary/50 flex items-center justify-center bg-black/40 backdrop-blur-xl">
                    <Trophy className="w-6 h-6 text-primary" />
                  </div>
                </div>

                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-black/40 backdrop-blur-xl p-3 rounded-2xl border border-white/10">
                  <Button variant="outline" size="icon" className="h-10 w-10 rounded-xl bg-transparent border-white/20 hover:bg-white/10 text-white" onClick={() => setCameraActive(!cameraActive)}>
                    {cameraActive ? <VideoIcon className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                  </Button>
                  <Button variant="destructive" size="icon" className="h-12 w-12 rounded-xl shadow-lg shadow-red-500/20" onClick={handleFinish}>
                    <Square className="w-5 h-5 fill-current" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-10 w-10 rounded-xl bg-transparent border-white/20 hover:bg-white/10 text-white" onClick={() => setMicActive(!micActive)}>
                    {micActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {/* AI Hint Box */}
              <div className="p-4 rounded-2xl bg-primary/5 border border-primary/20 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10 text-primary mt-0.5">
                  <BrainCircuit className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase text-primary mb-1">AI Coach Hint</p>
                  <p className="text-sm text-muted-foreground italic">"Try to focus on the STAR method for this behavioral question. Mention specific metrics and your direct impact."</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'submitting' && (
          <motion.div
            key="submitting"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex-1 flex flex-col items-center justify-center text-center space-y-6"
          >
            <div className="relative">
              <div className="w-24 h-24 rounded-full border-4 border-primary/20 animate-spin border-t-primary" />
              <div className="absolute inset-0 flex items-center justify-center">
                <BrainCircuit className="w-10 h-10 text-primary" />
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-bold">Analyzing Your Session</h2>
              <p className="text-muted-foreground max-w-sm">
                Our AI models are processing your video, transcript, and facial micro-expressions to generate a detailed report.
              </p>
            </div>
            <div className="flex gap-2 text-xs font-medium text-primary">
              <span className="animate-pulse">Whisper STT processing...</span>
              <span>•</span>
              <span className="animate-pulse delay-150">Sentiment analysis...</span>
              <span>•</span>
              <span className="animate-pulse delay-300">Scoring technical depth...</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Interview;
