import { RequestHandler } from "express";
import { Question, AIAnalysis, DashboardStats, AptitudeQuestion } from "@shared/api";

const MOCK_QUESTIONS: Question[] = [
  { id: '1', text: 'Explain the CAP theorem and how it applies to modern database selection.', category: 'System Design', difficulty: 'hard' },
  { id: '2', text: 'What is the time complexity of building a heap from an unsorted array?', category: 'Algorithms', difficulty: 'medium' },
  { id: '3', text: 'How do you handle a situation where you disagree with your manager\'s technical decision?', category: 'Behavioral', difficulty: 'easy' },
  { id: '4', text: 'What is a closure in JavaScript and how does it work under the hood?', category: 'Frontend', difficulty: 'medium' },
  { id: '5', text: 'Describe the Raft consensus algorithm.', category: 'Distributed Systems', difficulty: 'hard' },
];

const MOCK_APTITUDE: AptitudeQuestion[] = [
  // Quantitative
  {
    id: 'q1',
    question: 'A train 150m long passes a pole in 15 seconds. What is the speed of the train in km/hr?',
    options: ['30 km/hr', '36 km/hr', '40 km/hr', '45 km/hr'],
    correctAnswer: '36 km/hr',
    explanation: 'Speed = Distance / Time = 150 / 15 = 10 m/s. 10 * 18/5 = 36 km/hr.',
    category: 'quantitative'
  },
  {
    id: 'q2',
    question: 'A sum of money at simple interest amounts to $815 in 3 years and to $854 in 4 years. The sum is:',
    options: ['$650', '$690', '$698', '$700'],
    correctAnswer: '$698',
    explanation: 'S.I. for 1 year = 854 - 815 = 39. S.I. for 3 years = 39 * 3 = 117. Principal = 815 - 117 = 698.',
    category: 'quantitative'
  },
  {
    id: 'q3',
    question: 'The average of first five multiples of 3 is:',
    options: ['3', '9', '12', '15'],
    correctAnswer: '9',
    explanation: 'Average = (3 + 6 + 9 + 12 + 15) / 5 = 45 / 5 = 9.',
    category: 'quantitative'
  },
  {
    id: 'q4',
    question: 'Find the largest number which divides 62, 132 and 237 to leave the same remainder in each case.',
    options: ['30', '32', '35', '37'],
    correctAnswer: '35',
    explanation: 'Required number = HCF of (132-62), (237-132) and (237-62) = HCF of 70, 105, 175 = 35.',
    category: 'quantitative'
  },
  {
    id: 'q5',
    question: 'If 20% of a = b, then b% of 20 is the same as:',
    options: ['4% of a', '5% of a', '20% of a', 'None of these'],
    correctAnswer: '4% of a',
    explanation: 'b = 0.2a. b% of 20 = (b/100) * 20 = (0.2a/100) * 20 = 0.04a = 4% of a.',
    category: 'quantitative'
  },
  {
    id: 'q6',
    question: 'A shopkeeper sells an article for $240 and gains 20%. What is the cost price?',
    options: ['$200', '$210', '$220', '$225'],
    correctAnswer: '$200',
    explanation: 'CP = (SP * 100) / (100 + Gain%) = (240 * 100) / 120 = 200.',
    category: 'quantitative'
  },
  {
    id: 'q7',
    question: 'In how many ways can the letters of the word "LEADER" be arranged?',
    options: ['72', '144', '360', '720'],
    correctAnswer: '360',
    explanation: 'Total letters = 6, E repeats twice. Ways = 6! / 2! = 720 / 2 = 360.',
    category: 'quantitative'
  },
  {
    id: 'q8',
    question: 'A can do a work in 15 days and B in 20 days. If they work together for 4 days, then the fraction of work left is:',
    options: ['1/4', '1/10', '7/15', '8/15'],
    correctAnswer: '8/15',
    explanation: 'Work done in 1 day = 1/15 + 1/20 = 7/60. In 4 days = 4 * 7/60 = 7/15. Left = 1 - 7/15 = 8/15.',
    category: 'quantitative'
  },
  {
    id: 'q9',
    question: 'What is the compound interest on $2500 for 2 years at 4% per annum?',
    options: ['$200', '$202', '$204', '$206'],
    correctAnswer: '$204',
    explanation: 'Amount = 2500(1 + 4/100)^2 = 2500(1.04)^2 = 2500 * 1.0816 = 2704. CI = 2704 - 2500 = 204.',
    category: 'quantitative'
  },
  {
    id: 'q10',
    question: 'The ratio of two numbers is 3:4 and their HCF is 4. Their LCM is:',
    options: ['12', '16', '24', '48'],
    correctAnswer: '48',
    explanation: 'Numbers are 3x and 4x. HCF = x = 4. Numbers are 12 and 16. LCM(12, 16) = 48.',
    category: 'quantitative'
  },

  // Logical
  {
    id: 'l1',
    question: 'If "APPLE" is coded as "BQQMF", what is the code for "ORANGE"?',
    options: ['PSBOHF', 'PSCOHF', 'PTBOHF', 'PSBPHF'],
    correctAnswer: 'PSBOHF',
    explanation: 'Each letter is shifted by +1 in the alphabet.',
    category: 'logical'
  },
  {
    id: 'l2',
    question: 'Find the odd one out: 3, 5, 7, 9, 11, 13',
    options: ['7', '9', '11', '13'],
    correctAnswer: '9',
    explanation: '9 is a composite number, all others are prime.',
    category: 'logical'
  },
  {
    id: 'l3',
    question: 'Look at this series: 2, 1, (1/2), (1/4), ... What number should come next?',
    options: ['(1/3)', '(1/8)', '(2/8)', '(1/16)'],
    correctAnswer: '(1/8)',
    explanation: 'This is a geometric series where each number is half of the previous one.',
    category: 'logical'
  },
  {
    id: 'l4',
    question: 'Pointing to a photograph, a man said, "I have no brother or sister but that man\'s father is my father\'s son." Whose photograph was it?',
    options: ['His own', 'His son\'s', 'His father\'s', 'His nephew\'s'],
    correctAnswer: 'His son\'s',
    explanation: '"My father\'s son" is the man himself (since he has no siblings). So, the man in the photo\'s father is the speaker. Thus, it\'s his son.',
    category: 'logical'
  },
  {
    id: 'l5',
    question: 'Which word does NOT belong with the others?',
    options: ['Parsley', 'Basil', 'Dill', 'Mayonnaise'],
    correctAnswer: 'Mayonnaise',
    explanation: 'Parsley, basil, and dill are herbs. Mayonnaise is a condiment.',
    category: 'logical'
  },
  {
    id: 'l6',
    question: 'SCD, TEF, UGH, ____, WKL',
    options: ['CMN', 'UJI', 'VIJ', 'IJT'],
    correctAnswer: 'VIJ',
    explanation: 'First letter: S, T, U, V, W. Second and third: CD, EF, GH, IJ, KL.',
    category: 'logical'
  },
  {
    id: 'l7',
    question: 'Statements: All mangoes are golden in color. No golden-colored things are cheap. Conclusions: 1) All mangoes are cheap. 2) Golden-colored mangoes are not cheap.',
    options: ['Only 1 follows', 'Only 2 follows', 'Either 1 or 2 follows', 'Neither 1 nor 2 follows'],
    correctAnswer: 'Only 2 follows',
    explanation: 'Since no golden-colored things are cheap and all mangoes are golden, mangoes are not cheap.',
    category: 'logical'
  },
  {
    id: 'l8',
    question: 'If South-East becomes North, North-East becomes West and so on. What will West become?',
    options: ['North-East', 'South-East', 'South-West', 'North-West'],
    correctAnswer: 'South-East',
    explanation: 'The directions are rotated 135 degrees clockwise. West rotated 135 degrees clockwise becomes South-East.',
    category: 'logical'
  },
  {
    id: 'l9',
    question: 'A, B, C, D and E are sitting on a bench. A is sitting next to B, C is sitting next to D, D is not sitting with E who is on the left end of the bench. C is on the second position from the right. A is to the right of B and E. A and C are sitting together. In which position A is sitting?',
    options: ['Between B and D', 'Between B and C', 'Between E and D', 'Between C and E'],
    correctAnswer: 'Between B and C',
    explanation: 'Arrangement from left to right: E, B, A, C, D.',
    category: 'logical'
  },
  {
    id: 'l10',
    question: 'Find the missing number: 1, 4, 9, 16, 25, ?',
    options: ['30', '35', '36', '49'],
    correctAnswer: '36',
    explanation: 'These are squares of consecutive integers: 1^2, 2^2, 3^2, 4^2, 5^2, 6^2 = 36.',
    category: 'logical'
  },

  // Verbal
  {
    id: 'v1',
    question: 'Select the synonym for "Diligence".',
    options: ['Laziness', 'Persistence', 'Ignorance', 'Cowardice'],
    correctAnswer: 'Persistence',
    explanation: 'Diligence means careful and persistent work or effort.',
    category: 'verbal'
  },
  {
    id: 'v2',
    question: 'Find the correctly spelt word:',
    options: ['Efficient', 'Efficent', 'Eficient', 'Efficant'],
    correctAnswer: 'Efficient',
    explanation: 'The correct spelling is Efficient.',
    category: 'verbal'
  },
  {
    id: 'v3',
    question: 'Select the antonym for "Vague":',
    options: ['Unclear', 'Precise', 'Hazy', 'Indistinct'],
    correctAnswer: 'Precise',
    explanation: 'Vague means uncertain or unclear; Precise is its opposite.',
    category: 'verbal'
  },
  {
    id: 'v4',
    question: 'Choose the word that best fits the blank: The speaker\'s ____ tone made the audience feel uneasy.',
    options: ['Cheerful', 'Belligerent', 'Kind', 'Amicable'],
    correctAnswer: 'Belligerent',
    explanation: 'Belligerent means hostile and aggressive, which would make an audience uneasy.',
    category: 'verbal'
  },
  {
    id: 'v5',
    question: 'Identify the error in the sentence: "He don\'t know the answer to the question."',
    options: ['He', 'don\'t', 'know', 'to'],
    correctAnswer: 'don\'t',
    explanation: 'The subject "He" requires the third-person singular verb form "doesn\'t".',
    category: 'verbal'
  },
  {
    id: 'v6',
    question: 'Select the word that is most similar in meaning to "Aberration":',
    options: ['Normality', 'Deviation', 'Regularity', 'Conformity'],
    correctAnswer: 'Deviation',
    explanation: 'Aberration means a departure from what is normal or expected.',
    category: 'verbal'
  },
  {
    id: 'v7',
    question: 'What is the meaning of the idiom "To bite the bullet"?',
    options: ['To eat quickly', 'To accept something difficult', 'To start a fight', 'To finish a task'],
    correctAnswer: 'To accept something difficult',
    explanation: 'To bite the bullet means to accept something difficult or unpleasant that is unavoidable.',
    category: 'verbal'
  },
  {
    id: 'v8',
    question: 'Choose the correct preposition: She is proficient ____ three languages.',
    options: ['in', 'at', 'with', 'on'],
    correctAnswer: 'in',
    explanation: 'The correct idiom is "proficient in" a language.',
    category: 'verbal'
  },
  {
    id: 'v9',
    question: 'Select the correctly punctuated sentence:',
    options: ['I went to the store, but I forgot my wallet.', 'I went to the store but I forgot my wallet.', 'I went to the store; but I forgot my wallet.', 'I went to the store but, I forgot my wallet.'],
    correctAnswer: 'I went to the store, but I forgot my wallet.',
    explanation: 'A comma is needed before the coordinating conjunction "but" connecting two independent clauses.',
    category: 'verbal'
  },
  {
    id: 'v10',
    question: 'Analogies: "Ocean" is to "Water" as "Glacier" is to:',
    options: ['Mountain', 'Ice', 'Snow', 'River'],
    correctAnswer: 'Ice',
    explanation: 'An ocean is primarily made of water; a glacier is primarily made of ice.',
    category: 'verbal'
  }
];

export const getQuestions: RequestHandler = (req, res) => {
  const { role, difficulty } = req.query;
  // In a real app, filter based on query params
  res.json(MOCK_QUESTIONS);
};

export const getAptitudeQuestions: RequestHandler = (req, res) => {
  res.json(MOCK_APTITUDE);
};

export const analyzeAnswer: RequestHandler = (req, res) => {
  const { transcript, sessionId, questionId } = req.body;
  
  // Mock AI Analysis logic
  const analysis: AIAnalysis = {
    relevance: 85 + Math.random() * 10,
    clarity: 75 + Math.random() * 20,
    confidence: 80 + Math.random() * 15,
    technicalDepth: 70 + Math.random() * 25,
    feedback: "Your explanation of the core concepts was solid. However, you could have elaborated more on the trade-offs involved in the specific scenario mentioned.",
    emotionData: {
      smile: 40 + Math.random() * 40,
      eyeContact: 70 + Math.random() * 25,
      stress: 10 + Math.random() * 20
    }
  };

  res.json({
    id: Math.random().toString(36).substr(2, 9),
    sessionId,
    questionId,
    transcript,
    analysis,
    score: Math.round((analysis.relevance + analysis.clarity + analysis.technicalDepth) / 3)
  });
};

export const getStats: RequestHandler = (req, res) => {
  const stats: DashboardStats = {
    averageScore: 84,
    sessionsCount: 12,
    skillTrends: [
      { category: 'Data Structures', score: 90 },
      { category: 'Algorithms', score: 85 },
      { category: 'System Design', score: 70 },
      { category: 'Behavioral', score: 95 },
      { category: 'OS/Networking', score: 60 },
    ],
    weaknesses: ['Low-level Networking', 'Concurrency Controls']
  };
  res.json(stats);
};
